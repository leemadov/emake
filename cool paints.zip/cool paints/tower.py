import turtle
turtle.bgcolor('black')

squary = turtle.Turtle()
squary.speed(20)
squary.pencolor("red")
for i in range(4000):
    squary.forward(i)
    squary.right(91)