from sketchpy import library as lib
sketch = lib.tom_holland()
sketch.draw()
#you can change line 2 to sketch = lib.rdj()