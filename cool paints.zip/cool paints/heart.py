import turtle

t = turtle.Turtle()
s = turtle.Screen()
s.bgcolor("cyan")
t.speed(10)  # Adjust the turtle's speed

# Move to the starting position
t.penup()
t.goto(0, -200)
t.pendown()

# Draw the heart shape
t.begin_fill()
t.fillcolor("red")

t.left(140)
t.forward(224)
for _ in range(200):
    t.right(1)
    t.forward(2)
t.left(120)
for _ in range(200):
    t.right(1)
    t.forward(2)
t.forward(224)

t.end_fill()

turtle.done()
